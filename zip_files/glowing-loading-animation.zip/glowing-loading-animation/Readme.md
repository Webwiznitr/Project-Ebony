## Glow loading page animation

**Screenshot**

![glowing loading animation](./glowing-loading-animation.gif)

