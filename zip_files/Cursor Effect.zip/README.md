# Custom Cursor with Hover Effect

![](screencapture.gif)

Inspired by [technorax-v6.tech](https://technorax-v6.tech/)